# QEL · Listado R (Registro de Cambios) · A96 · v1.3
> Fecha: 2025-08-14 17:25:00 CST · Zona: America/Mexico_City

## Entradas (promoción cristalizada)
- [2025-08-14 17:25:00 CST] **Lámina 𝒱 — Consulta Detallada v1.0** — hoja operativa para cálculo de 𝒱 y V_final.
- [2025-08-14 17:25:00 CST] **Manual de Interpretación de Sombras v1.1 (humano)** — guía práctica ampliada.
- [2025-08-14 17:25:00 CST] **Tratado Metahumano v1.1 (ampliado)** — protocolo de seguridad con integraciones.

## Historial previo
- Ver v1.2 y anteriores en este mismo directorio.
